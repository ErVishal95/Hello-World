package OneWayEncrypt;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import Decoder.BASE64Encoder;
//import sun.misc.BASE64Encoder;
 
public final class EncriptTest {
    public static synchronized String encrypt(String plaintext,
            String algorithm, String encoding) throws Exception {
        MessageDigest msgDigest = null;
        String hashValue = null;
        try {
            msgDigest = MessageDigest.getInstance(algorithm);
            msgDigest.update(plaintext.getBytes(encoding));
            byte rawByte[] = msgDigest.digest();
           // hashValue = (new BASE64Encoder()).encode(rawByte);
            
            hashValue=(new BASE64Encoder().encode(rawByte));
        } catch (NoSuchAlgorithmException e) {
            System.out.println("No Such Algorithm Exists");
        } catch (UnsupportedEncodingException e) {
            System.out.println("The Encoding Is Not Supported");
        }
        return hashValue;
    }
 
    public static void main(String args[]) throws Exception {
        String plainPassword = "SecretPassword";
 
        System.out.println("PlainTexttAlgotEncodingtEncrypted Password");
        System.out.println(plainPassword +" "+ "tSHAtUTF-8t"
        		+" "+ encrypt("MySecretPassword", "SHA", "UTF-8"));
        System.out.println(plainPassword +" "+ "tSHA-1tUTF-16t"
        		+" "+ encrypt("MySecretPassword", "SHA-1", "UTF-16"));
        System.out.println(plainPassword +" "+ "tMD5tUTF-8t"
        		+" "+ encrypt("MySecretPassword", "MD5", "UTF-8"));
        System.out.println(plainPassword +" "+ "tMD5tUTF-16t"
        		+" "+ encrypt("MySecretPassword", "MD5", "UTF-16"));
 
    }
}
